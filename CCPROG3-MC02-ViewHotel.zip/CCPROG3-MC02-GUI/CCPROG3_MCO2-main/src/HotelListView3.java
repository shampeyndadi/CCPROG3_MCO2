import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class HotelListView3 extends JPanel {

    private Hotels hotels;
    private ArrayList<JButton> hotelButton;

    private JButton exitButton;

    public HotelListView3(Hotels hotels) {

        super();

        this.hotels = hotels;
        this.hotelButton = new ArrayList<>();


        setLayout(new BorderLayout());
        init();
        setSize(500, 500);



        setBackground(Color.decode("#FFFFFF"));

    }

    private void init() {
        JPanel panel = new JPanel();
        JLabel titleLabel = new JLabel("Specific information");

        titleLabel.setFont(new Font("Times New Roman", Font.ITALIC, 32));
        titleLabel.setForeground(Color.decode("#800080"));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setVerticalAlignment(JLabel.TOP);


        panel.setBackground(Color.decode("#FFFFFF"));
        panel.add(titleLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 7 , 10));


        for (Hotel hotels : hotels.HotelList()){
            System.out.println("Adding button for: " + hotels.getHotelName());
            JButton button = new JButton(hotels.getHotelName());
            button.setFont(new Font("Times New Roman", Font.BOLD, 20));
            button.setBackground(Color.decode("#FFFFFF"));
            button.setBorderPainted(false);
            button.setPreferredSize(new Dimension(24, 32));
            button.setForeground(Color.decode("#800080"));
            buttonPanel.add(button);

            hotelButton.add(button);
        }
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new FlowLayout());

        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        exitButton.setBackground(Color.decode("#FFFFFF"));
        exitButton.setForeground(Color.decode("#800080"));
        exitButton.setBorderPainted(false);

        southPanel.add(exitButton);
        //JScrollPane scrollPane = new JScrollPane(buttonPanel);


        //this.add(scrollPane, BorderLayout.EAST);
        this.add(panel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.CENTER);
        this.add(southPanel, BorderLayout.SOUTH);


    }
    public void addExitButtonListener(ActionListener listen) {
        this.exitButton.addActionListener(listen);
    }

    public void setActionHotelButtons(ActionListener listener){
        for (int i = 0; i < hotelButton.size(); i++){
            hotelButton.get(i).addActionListener(listener);
        }
    }

    public ArrayList<JButton> getButtons(){
        return hotelButton;
    }
}