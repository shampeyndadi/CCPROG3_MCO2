import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;

public class BasicDetailsView extends JPanel{

    private Hotel hotel;

    private JButton exitButton;

    private JPanel centerPanel;

    public BasicDetailsView(Hotel hotel){

        super();

        this.hotel = hotel;


        setLayout(new BorderLayout());

        init();

        setSize(500, 500);

        setBackground(Color.decode("#FFFFFF"));
    }

    private void init(){

        JPanel topPanel = new JPanel(new FlowLayout());
        JLabel topLabel = new JLabel("Basic Details");

        topLabel.setFont(new Font("Times New Roman", Font.ITALIC, 32));
        topLabel.setForeground(Color.decode("#800080"));
        topPanel.add(topLabel);

        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));


        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        exitButton.setForeground(Color.decode("#800080"));
        exitButton.setBackground(Color.decode("#FFFFFF"));
        exitButton.setBorderPainted(false);
        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.setBackground(Color.decode("#FFFFFF"));
        bottomPanel.add(exitButton);

        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

    }



    public void setExitButton (ActionListener listener){
        this.exitButton.addActionListener(listener);
    }

    public void setHotelName(){
        JLabel type = new JLabel("Hotel Name: " + hotel.getHotelName());
        type.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(type);
    }

    public void setHotelRooms(){
        JLabel price = new JLabel("Total Rooms: " + hotel.getTotalRooms());
        price.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(price);
    }

    public void setHotelEarning(){
        JLabel header = new JLabel("Total Earnings: " +hotel.getTotalEarnings());
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(header);


    }

}

