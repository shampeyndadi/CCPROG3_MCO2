import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReservationListView extends JPanel{

    private Hotel hotel;
    private ArrayList<JButton> reservationButton;
    private Hotels hotels;

    private JButton exitButton;

    public ReservationListView(Hotel hotel, Hotels hotels){

        super();
        this.hotels = hotels;
        this.hotel = hotel;

        this.reservationButton = new ArrayList<>();

        setLayout(new BorderLayout());
        init();
        setSize(500, 500);


        setBackground(Color.decode("#FFFFFF"));

    }

    private void init(){

        JPanel panel = new JPanel();
        JLabel titleLabel = new JLabel("Reservation Details");

        titleLabel.setFont(new Font("Times New Roman", Font.ITALIC, 32));
        titleLabel.setForeground(Color.decode("#800080"));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setVerticalAlignment(JLabel.TOP);


        panel.setBackground(Color.decode("#FFFFFF"));
        panel.add(titleLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 7 , 10));

        for(Hotel hotel: hotels.HotelList()) {
            for (Reservation reservation : hotel.viewReservations()) {
                System.out.println("Adding button for: " + reservation.guestName());
                JButton button = new JButton(reservation.guestName());
                button.setFont(new Font("Times New Roman", Font.BOLD, 20));
                button.setBackground(Color.decode("#FFFFFF"));
                button.setBorderPainted(false);
                button.setPreferredSize(new Dimension(24, 32));
                button.setForeground(Color.decode("#800080"));
                buttonPanel.add(button);

                reservationButton.add(button);
            }
        }
        //JScrollPane scrollPane = new JScrollPane(buttonPanel);
        //buttonPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel southPanel = new JPanel();
        southPanel.setLayout(new FlowLayout());

        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        exitButton.setBackground(Color.decode("#FFFFFF"));
        exitButton.setForeground(Color.decode("#800080"));
        exitButton.setBorderPainted(false);

        southPanel.add(exitButton);



        this.add(panel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.CENTER);
        this.add(southPanel, BorderLayout.SOUTH);


    }


    public void addExitButtonListener(ActionListener listen) {
        this.exitButton.addActionListener(listen);
    }

    public void setActionReservationButtons(ActionListener listener){
        for (int i = 0; i < reservationButton.size(); i++){
            reservationButton.get(i).addActionListener(listener);
        }
    }

    public ArrayList<JButton> getButtons(){
        return reservationButton;
    }

    public void setHotel(Hotel hotel){
        this.hotel = hotel;
    }

}



