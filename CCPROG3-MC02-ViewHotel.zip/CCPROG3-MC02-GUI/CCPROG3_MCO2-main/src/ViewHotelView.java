import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewHotelView extends JPanel {


    private JButton viewHotel;
    private JButton viewRoom;
    private JButton viewReservation;
    private JButton exitView;



    public ViewHotelView() {

        super();
        setLayout(new BorderLayout());
        setSize(450, 450);

        init();

        setBackground(Color.decode("#FFFFFF"));

    }

    private void init() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("View Information");

        titleLabel.setFont(new Font("Times New Roman", Font.ITALIC, 32));
        titleLabel.setForeground(Color.decode("#800080"));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setVerticalAlignment(JLabel.TOP);

        panel.setLayout(new FlowLayout());
        panel.setBackground(Color.decode("#FFFFFF"));
        panel.add(titleLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 1, 10 , 10));


        viewHotel = new JButton("Hotel Information");
        viewRoom = new JButton("Room Information");
        viewReservation = new JButton("Reservation Information");
        exitView = new JButton("Exit");



        viewHotel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        viewRoom.setFont(new Font("Times New Roman", Font.BOLD, 20));
        viewReservation.setFont(new Font("Times New Roman", Font.BOLD, 20));
        exitView.setFont(new Font("Times New Roman", Font.BOLD, 20));

        viewHotel.setForeground(Color.decode("#800080"));
        viewRoom.setForeground(Color.decode("#800080"));
        viewReservation.setForeground(Color.decode("#800080"));
        exitView.setForeground(Color.decode("#800080"));

        viewHotel.setBackground(Color.decode("#FFFFFF"));
        viewRoom.setBackground(Color.decode("#FFFFFF"));
        viewReservation.setBackground(Color.decode("#FFFFFF"));
        exitView.setBackground(Color.decode("#FFFFFF"));

        viewHotel.setBorderPainted(false);
        viewRoom.setBorderPainted(false);
        viewReservation.setBorderPainted(false);
        exitView.setBorderPainted(false);


        buttonPanel.add(viewHotel);
        buttonPanel.add(viewRoom);
        buttonPanel.add(viewReservation);
        buttonPanel.add(exitView);

        this.add(buttonPanel, BorderLayout.CENTER);
        this.add(panel, BorderLayout.NORTH);


    }



    public void addExitViewListener(ActionListener listen) {
        this.exitView.addActionListener(listen);
    }


    public void addHotelInfoListener(ActionListener listen) {
        this.viewHotel.addActionListener(listen);
    }

    public void addRoomInfoListener(ActionListener listen) {
        this.viewRoom.addActionListener(listen);
    }

    public void addReservationInfoListener(ActionListener listen) {
        this.viewReservation.addActionListener(listen);
    }

}