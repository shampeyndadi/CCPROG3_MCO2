import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;

public class RoomDetailsView extends JPanel{

    private Room chosenRoom;
    private ArrayList<Reservation> reservationList;


    private ArrayList<JLabel> dates;

    private JButton exitButton;

    private JPanel centerPanel;
    private JPanel datePanel;


    public RoomDetailsView(Room chosenRoom, ArrayList<Reservation> reservationList){

        super();

        this.chosenRoom = chosenRoom;
        this.reservationList = reservationList;

        this.dates = new ArrayList<>();

        setLayout(new BorderLayout());

        init();

        setSize(500, 500);

        setBackground(Color.decode("#FFFFFF"));
    }

    private void init(){

        JPanel topPanel = new JPanel(new FlowLayout());
        JLabel topLabel = new JLabel("Room Details");

        topLabel.setFont(new Font("Times New Roman", Font.ITALIC, 32));
        topLabel.setForeground(Color.decode("#800080"));
        topPanel.add(topLabel);

        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        datePanel = new JPanel();








            exitButton = new JButton("Exit");
            exitButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
            exitButton.setForeground(Color.decode("#800080"));
            exitButton.setBackground(Color.decode("#FFFFFF"));
            exitButton.setBorderPainted(false);
            JPanel bottomPanel = new JPanel(new FlowLayout());
            bottomPanel.setBackground(Color.decode("#FFFFFF"));
            bottomPanel.add(exitButton);

            add(topPanel, BorderLayout.NORTH);
            add(centerPanel, BorderLayout.CENTER);
            add(bottomPanel, BorderLayout.SOUTH);

            }



    public void setExitButton (ActionListener listener){
        this.exitButton.addActionListener(listener);
    }

    public void setRoomType(){
        JLabel type = new JLabel("Room Type: " + chosenRoom.getRoomType());
        type.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(type);
    }

    public void setRoomPrice(){
        JLabel price = new JLabel("Price: " + chosenRoom.getRoomPrice());
        price.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(price);
    }

    public void setRoomDates(){
        JLabel header = new JLabel("Available Dates: ");
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(header);

        for (int date : chosenRoom.getDatesAvailable(chosenRoom, reservationList)) {
            JLabel dateLabel = new JLabel("" + date);
            dates.add(dateLabel);
            datePanel.add(dateLabel);

        }
        centerPanel.add(datePanel, BorderLayout.SOUTH);

    }

    public ArrayList<JLabel> getDateLabels(){return dates;}

}

