import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;



public class ViewHotelController {
    private MainView mainView;
    private ViewHotelView viewHotelView;
    private Hotels hotels;
    private HotelListView hotelListView;
    private HotelListView2 hotelListView2;
    private HotelListView3 hotelListView3;
    private RoomListView roomListView;
    private RoomDetailsView roomDetailsView;
    private BasicDetailsView basicDetailsView;
    private ReservationListView reservationListView;
    private ReservationDetailsView reservationDetailsView;

    public ViewHotelController(MainView mainView, ViewHotelView viewHotelView, Hotels hotels, HotelListView hotelListView, HotelListView2 hotelListView2, HotelListView3 hotelListView3, RoomListView roomListView, ReservationListView reservationListView) {

        this.viewHotelView = viewHotelView;
        this.mainView = mainView;
        this.hotels = hotels;
        this.hotelListView = hotelListView;
        this.hotelListView2 = hotelListView2;
        this.hotelListView3 = hotelListView3;
        this.roomListView = roomListView;
        this.reservationListView = reservationListView;

        this.viewHotelView.addHotelInfoListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.setContentPane(hotelListView2);
                mainView.revalidate();
                mainView.repaint();

            }
        });

        this.viewHotelView.addRoomInfoListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.setContentPane(hotelListView);
                mainView.revalidate();
                mainView.repaint();

            }
        });

        this.viewHotelView.addReservationInfoListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.setContentPane(hotelListView3);
                mainView.revalidate();
                mainView.repaint();
            }
        });

        this.hotelListView2.setActionHotelButtons(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                String hotelName = source.getText();

                for (Hotel hotel : hotels.HotelList()) {
                    if (hotel.getHotelName().equals(hotelName)) {
                        basicDetailsView = new BasicDetailsView(hotel);

                        basicDetailsView.setHotelName();
                        basicDetailsView.setHotelRooms();
                        basicDetailsView.setHotelEarning();

                        basicDetailsView.setExitButton(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                mainView.switchToMainPanel();
                            }
                        });
                        mainView.setContentPane(basicDetailsView);
                        mainView.revalidate();
                        mainView.repaint();

                        System.out.println("You clicked on " + hotelName);
                        break;
                    }

                }

            }
        });
        this.hotelListView.setActionHotelButtons(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                String hotelName = source.getText();

                for (Hotel hotel : hotels.HotelList()) {
                    if (hotel.getHotelName().equals(hotelName)) {
                        roomListView.setHotel(hotel);
                        mainView.setContentPane(roomListView);
                        mainView.revalidate();
                        mainView.repaint();

                        System.out.println("You clicked on " + hotelName);
                        break;
                    }

                }
            }

        });

        this.roomListView.setActionRoomButtons(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source2 = (JButton) e.getSource();
                String roomName = source2.getText();


                for (Hotel hotel : hotels.HotelList()) {
                    for (Room room : hotel.viewRooms()) {
                        if (room.getRoomName().equals(roomName)) {

                            roomDetailsView = new RoomDetailsView(room, hotel.viewReservations());
                            roomDetailsView.setRoomType();
                            roomDetailsView.setRoomPrice();
                            roomDetailsView.setRoomDates();

                            roomDetailsView.setExitButton(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    mainView.switchToMainPanel();
                                }
                            });

                            mainView.setContentPane(roomDetailsView);
                            mainView.revalidate();
                            mainView.repaint();

                            System.out.println("You clicked on " + roomName);
                            break;

                        }
                    }
                }
            }
        });

        this.hotelListView3.setActionHotelButtons(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                String hotelName = source.getText();

                for (Hotel hotel : hotels.HotelList()) {
                    if (hotel.getHotelName().equals(hotelName)) {
                        roomListView.setHotel(hotel);
                        mainView.setContentPane(reservationListView);
                        mainView.revalidate();
                        mainView.repaint();

                        System.out.println("You clicked on " + hotelName);
                        break;
                    }

                }
            }

        });

        this.reservationListView.setActionReservationButtons(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                String reservationName = source.getText();

                for (Hotel hotel : hotels.HotelList()) {
                    for (Reservation reservation : hotel.viewReservations()) {
                        if (reservation.guestName().equals(reservationName)) {

                            reservationDetailsView = new ReservationDetailsView(reservation);
                            reservationDetailsView.setReservationName();
                            reservationDetailsView.setReservationRoom();
                            reservationDetailsView.setReservationLength();
                            reservationDetailsView.setReservationBreakDown();


                            reservationDetailsView.setExitButton(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    mainView.switchToMainPanel();
                                }
                            });

                            mainView.setContentPane(reservationDetailsView);
                            mainView.revalidate();
                            mainView.repaint();

                            System.out.println("You clicked on " + reservationName);
                            break;

                        }
                    }
                }

            }
        });

        this.roomListView.addExitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.switchToMainPanel();
            }
        });

        this.hotelListView.addExitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.switchToMainPanel();
            }
        });

        this.viewHotelView.addExitViewListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.switchToMainPanel();
            }
        });

        this.hotelListView2.addExitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.switchToMainPanel();
            }
        });

        this.hotelListView3.addExitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.switchToMainPanel();
            }
        });

    }
}